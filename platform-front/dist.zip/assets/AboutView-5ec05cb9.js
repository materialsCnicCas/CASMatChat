import{r as L,w as pe,a as lo,h as ao,o as co,b as so,c as ce,d as uo,e as se,f as $,g as u,i as $e,j as Le,k as ve,l as re,m as M,n as x,p as D,u as oe,T as vo,q as Be,s as q,t as mo,F as Ie,v as h,x as z,y as ne,z as N,A as p,B as ye,C as B,D as De,E as he,G as W,H as Y,I as Ee,J as me,N as po,K as ho,L as fo,M as _e,O as go,_ as xo,P as bo,Q as ie,R as le,S as F,U as xe,V as be,W as U,X as ke,Y as yo,Z as Te,$ as wo,a0 as Co,a1 as we,a2 as Io,a3 as zo,a4 as So,a5 as Ao,a6 as Ho,a7 as Po,a8 as No}from"./index-5b83db83.js";import{N as Ro,C as _o,l as ko}from"./interface-79492ade.js";import{p as To,a as je,V as Ko,b as Oo,c as Fo,h as Ke,m as Mo,d as $o,r as Lo,f as Bo,e as Ve,N as Do,g as Ue,t as Eo,i as jo,k as ze}from"./Tooltip-122ae05b.js";import{X as Vo,_ as Uo}from"./Button-c30b77f0.js";function Wo(e){return t=>{t?e.value=t.$el:e.value=null}}function qo(e,t,o){if(!t)return e;const n=L(e.value);let i=null;return pe(e,l=>{i!==null&&window.clearTimeout(i),l===!0?o&&!o.value?n.value=!0:i=window.setTimeout(()=>{n.value=!0},t):n.value=!1}),n}function Go(e={},t){const o=lo({ctrl:!1,command:!1,win:!1,shift:!1,tab:!1}),{keydown:n,keyup:i}=e,l=d=>{switch(d.key){case"Control":o.ctrl=!0;break;case"Meta":o.command=!0,o.win=!0;break;case"Shift":o.shift=!0;break;case"Tab":o.tab=!0;break}n!==void 0&&Object.keys(n).forEach(f=>{if(f!==d.key)return;const b=n[f];if(typeof b=="function")b(d);else{const{stop:w=!1,prevent:m=!1}=b;w&&d.stopPropagation(),m&&d.preventDefault(),b.handler(d)}})},c=d=>{switch(d.key){case"Control":o.ctrl=!1;break;case"Meta":o.command=!1,o.win=!1;break;case"Shift":o.shift=!1;break;case"Tab":o.tab=!1;break}i!==void 0&&Object.keys(i).forEach(f=>{if(f!==d.key)return;const b=i[f];if(typeof b=="function")b(d);else{const{stop:w=!1,prevent:m=!1}=b;w&&d.stopPropagation(),m&&d.preventDefault(),b.handler(d)}})},s=()=>{(t===void 0||t.value)&&(se("keydown",document,l),se("keyup",document,c)),t!==void 0&&pe(t,d=>{d?(se("keydown",document,l),se("keyup",document,c)):(ce("keydown",document,l),ce("keyup",document,c))})};return ao()?(co(s),so(()=>{(t===void 0||t.value)&&(ce("keydown",document,l),ce("keyup",document,c))})):s(),uo(o)}const Xo=$({name:"ChevronDownFilled",render(){return u("svg",{viewBox:"0 0 16 16",fill:"none",xmlns:"http://www.w3.org/2000/svg"},u("path",{d:"M3.20041 5.73966C3.48226 5.43613 3.95681 5.41856 4.26034 5.70041L8 9.22652L11.7397 5.70041C12.0432 5.41856 12.5177 5.43613 12.7996 5.73966C13.0815 6.0432 13.0639 6.51775 12.7603 6.7996L8.51034 10.7996C8.22258 11.0668 7.77743 11.0668 7.48967 10.7996L3.23966 6.7996C2.93613 6.51775 2.91856 6.0432 3.20041 5.73966Z",fill:"currentColor"}))}}),Zo={padding:"4px 0",optionIconSizeSmall:"14px",optionIconSizeMedium:"16px",optionIconSizeLarge:"16px",optionIconSizeHuge:"18px",optionSuffixWidthSmall:"14px",optionSuffixWidthMedium:"14px",optionSuffixWidthLarge:"16px",optionSuffixWidthHuge:"16px",optionIconSuffixWidthSmall:"32px",optionIconSuffixWidthMedium:"32px",optionIconSuffixWidthLarge:"36px",optionIconSuffixWidthHuge:"36px",optionPrefixWidthSmall:"14px",optionPrefixWidthMedium:"14px",optionPrefixWidthLarge:"16px",optionPrefixWidthHuge:"16px",optionIconPrefixWidthSmall:"36px",optionIconPrefixWidthMedium:"36px",optionIconPrefixWidthLarge:"40px",optionIconPrefixWidthHuge:"40px"},Jo=e=>{const{primaryColor:t,textColor2:o,dividerColor:n,hoverColor:i,popoverColor:l,invertedColor:c,borderRadius:s,fontSizeSmall:d,fontSizeMedium:f,fontSizeLarge:b,fontSizeHuge:w,heightSmall:m,heightMedium:P,heightLarge:_,heightHuge:R,textColor3:H,opacityDisabled:O}=e;return Object.assign(Object.assign({},Zo),{optionHeightSmall:m,optionHeightMedium:P,optionHeightLarge:_,optionHeightHuge:R,borderRadius:s,fontSizeSmall:d,fontSizeMedium:f,fontSizeLarge:b,fontSizeHuge:w,optionTextColor:o,optionTextColorHover:o,optionTextColorActive:t,optionTextColorChildActive:t,color:l,dividerColor:n,suffixColor:o,prefixColor:o,optionColorHover:i,optionColorActive:ve(t,{alpha:.1}),groupHeaderTextColor:H,optionTextColorInverted:"#BBB",optionTextColorHoverInverted:"#FFF",optionTextColorActiveInverted:"#FFF",optionTextColorChildActiveInverted:"#FFF",colorInverted:c,dividerColorInverted:"#BBB",suffixColorInverted:"#BBB",prefixColorInverted:"#BBB",optionColorHoverInverted:t,optionColorActiveInverted:t,groupHeaderTextColorInverted:"#AAA",optionOpacityDisabled:O})},Qo=$e({name:"Dropdown",common:Le,peers:{Popover:To},self:Jo}),We=Qo,qe=$({name:"DropdownDivider",props:{clsPrefix:{type:String,required:!0}},render(){return u("div",{class:`${this.clsPrefix}-dropdown-divider`})}}),Se=re("n-dropdown-menu"),fe=re("n-dropdown"),Oe=re("n-dropdown-option");function Ce(e,t){return e.type==="submenu"||e.type===void 0&&e[t]!==void 0}function Yo(e){return e.type==="group"}function Ge(e){return e.type==="divider"}function et(e){return e.type==="render"}const Xe=$({name:"DropdownOption",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0},parentKey:{type:[String,Number],default:null},placement:{type:String,default:"right-start"},props:Object,scrollable:Boolean},setup(e){const t=M(fe),{hoverKeyRef:o,keyboardKeyRef:n,lastToggledSubmenuKeyRef:i,pendingKeyPathRef:l,activeKeyPathRef:c,animatedRef:s,mergedShowRef:d,renderLabelRef:f,renderIconRef:b,labelFieldRef:w,childrenFieldRef:m,renderOptionRef:P,nodePropsRef:_,menuPropsRef:R}=t,H=M(Oe,null),O=M(Se),G=M(je),X=x(()=>e.tmNode.rawNode),E=x(()=>{const{value:y}=m;return Ce(e.tmNode.rawNode,y)}),j=x(()=>{const{disabled:y}=e.tmNode;return y}),te=x(()=>{if(!E.value)return!1;const{key:y,disabled:K}=e.tmNode;if(K)return!1;const{value:Z}=o,{value:J}=n,{value:ge}=i,{value:Q}=l;return Z!==null?Q.includes(y):J!==null?Q.includes(y)&&Q[Q.length-1]!==y:ge!==null?Q.includes(y):!1}),V=x(()=>n.value===null&&!s.value),C=qo(te,300,V),I=x(()=>!!(H!=null&&H.enteringSubmenuRef.value)),r=L(!1);D(Oe,{enteringSubmenuRef:r});function g(){r.value=!0}function v(){r.value=!1}function k(){const{parentKey:y,tmNode:K}=e;K.disabled||d.value&&(i.value=y,n.value=null,o.value=K.key)}function A(){const{tmNode:y}=e;y.disabled||d.value&&o.value!==y.key&&k()}function S(y){if(e.tmNode.disabled||!d.value)return;const{relatedTarget:K}=y;K&&!Ke({target:K},"dropdownOption")&&!Ke({target:K},"scrollbarRail")&&(o.value=null)}function a(){const{value:y}=E,{tmNode:K}=e;d.value&&!y&&!K.disabled&&(t.doSelect(K.key,K.rawNode),t.doUpdateShow(!1))}return{labelField:w,renderLabel:f,renderIcon:b,siblingHasIcon:O.showIconRef,siblingHasSubmenu:O.hasSubmenuRef,menuProps:R,popoverBody:G,animated:s,mergedShowSubmenu:x(()=>C.value&&!I.value),rawNode:X,hasSubmenu:E,pending:oe(()=>{const{value:y}=l,{key:K}=e.tmNode;return y.includes(K)}),childActive:oe(()=>{const{value:y}=c,{key:K}=e.tmNode,Z=y.findIndex(J=>K===J);return Z===-1?!1:Z<y.length-1}),active:oe(()=>{const{value:y}=c,{key:K}=e.tmNode,Z=y.findIndex(J=>K===J);return Z===-1?!1:Z===y.length-1}),mergedDisabled:j,renderOption:P,nodeProps:_,handleClick:a,handleMouseMove:A,handleMouseEnter:k,handleMouseLeave:S,handleSubmenuBeforeEnter:g,handleSubmenuAfterEnter:v}},render(){var e,t;const{animated:o,rawNode:n,mergedShowSubmenu:i,clsPrefix:l,siblingHasIcon:c,siblingHasSubmenu:s,renderLabel:d,renderIcon:f,renderOption:b,nodeProps:w,props:m,scrollable:P}=this;let _=null;if(i){const G=(e=this.menuProps)===null||e===void 0?void 0:e.call(this,n,n.children);_=u(Ze,Object.assign({},G,{clsPrefix:l,scrollable:this.scrollable,tmNodes:this.tmNode.children,parentKey:this.tmNode.key}))}const R={class:[`${l}-dropdown-option-body`,this.pending&&`${l}-dropdown-option-body--pending`,this.active&&`${l}-dropdown-option-body--active`,this.childActive&&`${l}-dropdown-option-body--child-active`,this.mergedDisabled&&`${l}-dropdown-option-body--disabled`],onMousemove:this.handleMouseMove,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onClick:this.handleClick},H=w==null?void 0:w(n),O=u("div",Object.assign({class:[`${l}-dropdown-option`,H==null?void 0:H.class],"data-dropdown-option":!0},H),u("div",Be(R,m),[u("div",{class:[`${l}-dropdown-option-body__prefix`,c&&`${l}-dropdown-option-body__prefix--show-icon`]},[f?f(n):q(n.icon)]),u("div",{"data-dropdown-option":!0,class:`${l}-dropdown-option-body__label`},d?d(n):q((t=n[this.labelField])!==null&&t!==void 0?t:n.title)),u("div",{"data-dropdown-option":!0,class:[`${l}-dropdown-option-body__suffix`,s&&`${l}-dropdown-option-body__suffix--has-submenu`]},this.hasSubmenu?u(Ro,null,{default:()=>u(_o,null)}):null)]),this.hasSubmenu?u(Ko,null,{default:()=>[u(Oo,null,{default:()=>u("div",{class:`${l}-dropdown-offset-container`},u(Fo,{show:this.mergedShowSubmenu,placement:this.placement,to:P&&this.popoverBody||void 0,teleportDisabled:!P},{default:()=>u("div",{class:`${l}-dropdown-menu-wrapper`},o?u(vo,{onBeforeEnter:this.handleSubmenuBeforeEnter,onAfterEnter:this.handleSubmenuAfterEnter,name:"fade-in-scale-up-transition",appear:!0},{default:()=>_}):_)}))})]}):null);return b?b({node:O,option:n}):O}}),ot=$({name:"DropdownGroupHeader",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){const{showIconRef:e,hasSubmenuRef:t}=M(Se),{renderLabelRef:o,labelFieldRef:n,nodePropsRef:i,renderOptionRef:l}=M(fe);return{labelField:n,showIcon:e,hasSubmenu:t,renderLabel:o,nodeProps:i,renderOption:l}},render(){var e;const{clsPrefix:t,hasSubmenu:o,showIcon:n,nodeProps:i,renderLabel:l,renderOption:c}=this,{rawNode:s}=this.tmNode,d=u("div",Object.assign({class:`${t}-dropdown-option`},i==null?void 0:i(s)),u("div",{class:`${t}-dropdown-option-body ${t}-dropdown-option-body--group`},u("div",{"data-dropdown-option":!0,class:[`${t}-dropdown-option-body__prefix`,n&&`${t}-dropdown-option-body__prefix--show-icon`]},q(s.icon)),u("div",{class:`${t}-dropdown-option-body__label`,"data-dropdown-option":!0},l?l(s):q((e=s.title)!==null&&e!==void 0?e:s[this.labelField])),u("div",{class:[`${t}-dropdown-option-body__suffix`,o&&`${t}-dropdown-option-body__suffix--has-submenu`],"data-dropdown-option":!0})));return c?c({node:d,option:s}):d}}),tt=$({name:"NDropdownGroup",props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0},parentKey:{type:[String,Number],default:null}},render(){const{tmNode:e,parentKey:t,clsPrefix:o}=this,{children:n}=e;return u(Ie,null,u(ot,{clsPrefix:o,tmNode:e,key:e.key}),n==null?void 0:n.map(i=>{const{rawNode:l}=i;return l.show===!1?null:Ge(l)?u(qe,{clsPrefix:o,key:i.key}):i.isGroup?(mo("dropdown","`group` node is not allowed to be put in `group` node."),null):u(Xe,{clsPrefix:o,tmNode:i,parentKey:t,key:i.key})}))}}),nt=$({name:"DropdownRenderOption",props:{tmNode:{type:Object,required:!0}},render(){const{rawNode:{render:e,props:t}}=this.tmNode;return u("div",t,[e==null?void 0:e()])}}),Ze=$({name:"DropdownMenu",props:{scrollable:Boolean,showArrow:Boolean,arrowStyle:[String,Object],clsPrefix:{type:String,required:!0},tmNodes:{type:Array,default:()=>[]},parentKey:{type:[String,Number],default:null}},setup(e){const{renderIconRef:t,childrenFieldRef:o}=M(fe);D(Se,{showIconRef:x(()=>{const i=t.value;return e.tmNodes.some(l=>{var c;if(l.isGroup)return(c=l.children)===null||c===void 0?void 0:c.some(({rawNode:d})=>i?i(d):d.icon);const{rawNode:s}=l;return i?i(s):s.icon})}),hasSubmenuRef:x(()=>{const{value:i}=o;return e.tmNodes.some(l=>{var c;if(l.isGroup)return(c=l.children)===null||c===void 0?void 0:c.some(({rawNode:d})=>Ce(d,i));const{rawNode:s}=l;return Ce(s,i)})})});const n=L(null);return D(Mo,null),D($o,null),D(je,n),{bodyRef:n}},render(){const{parentKey:e,clsPrefix:t,scrollable:o}=this,n=this.tmNodes.map(i=>{const{rawNode:l}=i;return l.show===!1?null:et(l)?u(nt,{tmNode:i,key:i.key}):Ge(l)?u(qe,{clsPrefix:t,key:i.key}):Yo(l)?u(tt,{clsPrefix:t,tmNode:i,parentKey:e,key:i.key}):u(Xe,{clsPrefix:t,tmNode:i,parentKey:e,key:i.key,props:l.props,scrollable:o})});return u("div",{class:[`${t}-dropdown-menu`,o&&`${t}-dropdown-menu--scrollable`],ref:"bodyRef"},o?u(Vo,{contentClass:`${t}-dropdown-menu__content`},{default:()=>n}):n,this.showArrow?Lo({clsPrefix:t,arrowStyle:this.arrowStyle}):null)}}),rt=h("dropdown-menu",`
 transform-origin: var(--v-transform-origin);
 background-color: var(--n-color);
 border-radius: var(--n-border-radius);
 box-shadow: var(--n-box-shadow);
 position: relative;
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
`,[Bo(),h("dropdown-option",`
 position: relative;
 `,[z("a",`
 text-decoration: none;
 color: inherit;
 outline: none;
 `,[z("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),h("dropdown-option-body",`
 display: flex;
 cursor: pointer;
 position: relative;
 height: var(--n-option-height);
 line-height: var(--n-option-height);
 font-size: var(--n-font-size);
 color: var(--n-option-text-color);
 transition: color .3s var(--n-bezier);
 `,[z("&::before",`
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 left: 4px;
 right: 4px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `),ne("disabled",[N("pending",`
 color: var(--n-option-text-color-hover);
 `,[p("prefix, suffix",`
 color: var(--n-option-text-color-hover);
 `),z("&::before","background-color: var(--n-option-color-hover);")]),N("active",`
 color: var(--n-option-text-color-active);
 `,[p("prefix, suffix",`
 color: var(--n-option-text-color-active);
 `),z("&::before","background-color: var(--n-option-color-active);")]),N("child-active",`
 color: var(--n-option-text-color-child-active);
 `,[p("prefix, suffix",`
 color: var(--n-option-text-color-child-active);
 `)])]),N("disabled",`
 cursor: not-allowed;
 opacity: var(--n-option-opacity-disabled);
 `),N("group",`
 font-size: calc(var(--n-font-size) - 1px);
 color: var(--n-group-header-text-color);
 `,[p("prefix",`
 width: calc(var(--n-option-prefix-width) / 2);
 `,[N("show-icon",`
 width: calc(var(--n-option-icon-prefix-width) / 2);
 `)])]),p("prefix",`
 width: var(--n-option-prefix-width);
 display: flex;
 justify-content: center;
 align-items: center;
 color: var(--n-prefix-color);
 transition: color .3s var(--n-bezier);
 z-index: 1;
 `,[N("show-icon",`
 width: var(--n-option-icon-prefix-width);
 `),h("icon",`
 font-size: var(--n-option-icon-size);
 `)]),p("label",`
 white-space: nowrap;
 flex: 1;
 z-index: 1;
 `),p("suffix",`
 box-sizing: border-box;
 flex-grow: 0;
 flex-shrink: 0;
 display: flex;
 justify-content: flex-end;
 align-items: center;
 min-width: var(--n-option-suffix-width);
 padding: 0 8px;
 transition: color .3s var(--n-bezier);
 color: var(--n-suffix-color);
 z-index: 1;
 `,[N("has-submenu",`
 width: var(--n-option-icon-suffix-width);
 `),h("icon",`
 font-size: var(--n-option-icon-size);
 `)]),h("dropdown-menu","pointer-events: all;")]),h("dropdown-offset-container",`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: -4px;
 bottom: -4px;
 `)]),h("dropdown-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 4px 0;
 `),h("dropdown-menu-wrapper",`
 transform-origin: var(--v-transform-origin);
 width: fit-content;
 `),z(">",[h("scrollbar",`
 height: inherit;
 max-height: inherit;
 `)]),ne("scrollable",`
 padding: var(--n-padding);
 `),N("scrollable",[p("content",`
 padding: var(--n-padding);
 `)])]),it={animated:{type:Boolean,default:!0},keyboard:{type:Boolean,default:!0},size:{type:String,default:"medium"},inverted:Boolean,placement:{type:String,default:"bottom"},onSelect:[Function,Array],options:{type:Array,default:()=>[]},menuProps:Function,showArrow:Boolean,renderLabel:Function,renderIcon:Function,renderOption:Function,nodeProps:Function,labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},value:[String,Number]},lt=Object.keys(Ue),at=Object.assign(Object.assign(Object.assign({},Ue),it),he.props),dt=$({name:"Dropdown",inheritAttrs:!1,props:at,setup(e){const t=L(!1),o=ye(B(e,"show"),t),n=x(()=>{const{keyField:v,childrenField:k}=e;return Ve(e.options,{getKey(A){return A[v]},getDisabled(A){return A.disabled===!0},getIgnored(A){return A.type==="divider"||A.type==="render"},getChildren(A){return A[k]}})}),i=x(()=>n.value.treeNodes),l=L(null),c=L(null),s=L(null),d=x(()=>{var v,k,A;return(A=(k=(v=l.value)!==null&&v!==void 0?v:c.value)!==null&&k!==void 0?k:s.value)!==null&&A!==void 0?A:null}),f=x(()=>n.value.getPath(d.value).keyPath),b=x(()=>n.value.getPath(e.value).keyPath),w=oe(()=>e.keyboard&&o.value);Go({keydown:{ArrowUp:{prevent:!0,handler:j},ArrowRight:{prevent:!0,handler:E},ArrowDown:{prevent:!0,handler:te},ArrowLeft:{prevent:!0,handler:X},Enter:{prevent:!0,handler:V},Escape:G}},w);const{mergedClsPrefixRef:m,inlineThemeDisabled:P}=De(e),_=he("Dropdown","-dropdown",rt,We,e,m);D(fe,{labelFieldRef:B(e,"labelField"),childrenFieldRef:B(e,"childrenField"),renderLabelRef:B(e,"renderLabel"),renderIconRef:B(e,"renderIcon"),hoverKeyRef:l,keyboardKeyRef:c,lastToggledSubmenuKeyRef:s,pendingKeyPathRef:f,activeKeyPathRef:b,animatedRef:B(e,"animated"),mergedShowRef:o,nodePropsRef:B(e,"nodeProps"),renderOptionRef:B(e,"renderOption"),menuPropsRef:B(e,"menuProps"),doSelect:R,doUpdateShow:H}),pe(o,v=>{!e.animated&&!v&&O()});function R(v,k){const{onSelect:A}=e;A&&W(A,v,k)}function H(v){const{"onUpdate:show":k,onUpdateShow:A}=e;k&&W(k,v),A&&W(A,v),t.value=v}function O(){l.value=null,c.value=null,s.value=null}function G(){H(!1)}function X(){I("left")}function E(){I("right")}function j(){I("up")}function te(){I("down")}function V(){const v=C();v!=null&&v.isLeaf&&o.value&&(R(v.key,v.rawNode),H(!1))}function C(){var v;const{value:k}=n,{value:A}=d;return!k||A===null?null:(v=k.getNode(A))!==null&&v!==void 0?v:null}function I(v){const{value:k}=d,{value:{getFirstAvailableNode:A}}=n;let S=null;if(k===null){const a=A();a!==null&&(S=a.key)}else{const a=C();if(a){let y;switch(v){case"down":y=a.getNext();break;case"up":y=a.getPrev();break;case"right":y=a.getChild();break;case"left":y=a.getParent();break}y&&(S=y.key)}}S!==null&&(l.value=null,c.value=S)}const r=x(()=>{const{size:v,inverted:k}=e,{common:{cubicBezierEaseInOut:A},self:S}=_.value,{padding:a,dividerColor:y,borderRadius:K,optionOpacityDisabled:Z,[Y("optionIconSuffixWidth",v)]:J,[Y("optionSuffixWidth",v)]:ge,[Y("optionIconPrefixWidth",v)]:Q,[Y("optionPrefixWidth",v)]:to,[Y("fontSize",v)]:no,[Y("optionHeight",v)]:ro,[Y("optionIconSize",v)]:io}=S,T={"--n-bezier":A,"--n-font-size":no,"--n-padding":a,"--n-border-radius":K,"--n-option-height":ro,"--n-option-prefix-width":to,"--n-option-icon-prefix-width":Q,"--n-option-suffix-width":ge,"--n-option-icon-suffix-width":J,"--n-option-icon-size":io,"--n-divider-color":y,"--n-option-opacity-disabled":Z};return k?(T["--n-color"]=S.colorInverted,T["--n-option-color-hover"]=S.optionColorHoverInverted,T["--n-option-color-active"]=S.optionColorActiveInverted,T["--n-option-text-color"]=S.optionTextColorInverted,T["--n-option-text-color-hover"]=S.optionTextColorHoverInverted,T["--n-option-text-color-active"]=S.optionTextColorActiveInverted,T["--n-option-text-color-child-active"]=S.optionTextColorChildActiveInverted,T["--n-prefix-color"]=S.prefixColorInverted,T["--n-suffix-color"]=S.suffixColorInverted,T["--n-group-header-text-color"]=S.groupHeaderTextColorInverted):(T["--n-color"]=S.color,T["--n-option-color-hover"]=S.optionColorHover,T["--n-option-color-active"]=S.optionColorActive,T["--n-option-text-color"]=S.optionTextColor,T["--n-option-text-color-hover"]=S.optionTextColorHover,T["--n-option-text-color-active"]=S.optionTextColorActive,T["--n-option-text-color-child-active"]=S.optionTextColorChildActive,T["--n-prefix-color"]=S.prefixColor,T["--n-suffix-color"]=S.suffixColor,T["--n-group-header-text-color"]=S.groupHeaderTextColor),T}),g=P?Ee("dropdown",x(()=>`${e.size[0]}${e.inverted?"i":""}`),r,e):void 0;return{mergedClsPrefix:m,mergedTheme:_,tmNodes:i,mergedShow:o,handleAfterLeave:()=>{e.animated&&O()},doUpdateShow:H,cssVars:P?void 0:r,themeClass:g==null?void 0:g.themeClass,onRender:g==null?void 0:g.onRender}},render(){const e=(n,i,l,c,s)=>{var d;const{mergedClsPrefix:f,menuProps:b}=this;(d=this.onRender)===null||d===void 0||d.call(this);const w=(b==null?void 0:b(void 0,this.tmNodes.map(P=>P.rawNode)))||{},m={ref:Wo(i),class:[n,`${f}-dropdown`,this.themeClass],clsPrefix:f,tmNodes:this.tmNodes,style:[l,this.cssVars],showArrow:this.showArrow,arrowStyle:this.arrowStyle,scrollable:this.scrollable,onMouseenter:c,onMouseleave:s};return u(Ze,Be(this.$attrs,m,w))},{mergedTheme:t}=this,o={show:this.mergedShow,theme:t.peers.Popover,themeOverrides:t.peerOverrides.Popover,internalOnAfterLeave:this.handleAfterLeave,internalRenderBody:e,onUpdateShow:this.doUpdateShow,"onUpdate:show":void 0};return u(Do,Object.assign({},me(this.$props,lt),o),{trigger:()=>{var n,i;return(i=(n=this.$slots).default)===null||i===void 0?void 0:i.call(n)}})}});function ct(e,t,o,n){return{itemColorHoverInverted:"#0000",itemColorActiveInverted:t,itemColorActiveHoverInverted:t,itemColorActiveCollapsedInverted:t,itemTextColorInverted:e,itemTextColorHoverInverted:o,itemTextColorChildActiveInverted:o,itemTextColorChildActiveHoverInverted:o,itemTextColorActiveInverted:o,itemTextColorActiveHoverInverted:o,itemTextColorHorizontalInverted:e,itemTextColorHoverHorizontalInverted:o,itemTextColorChildActiveHorizontalInverted:o,itemTextColorChildActiveHoverHorizontalInverted:o,itemTextColorActiveHorizontalInverted:o,itemTextColorActiveHoverHorizontalInverted:o,itemIconColorInverted:e,itemIconColorHoverInverted:o,itemIconColorActiveInverted:o,itemIconColorActiveHoverInverted:o,itemIconColorChildActiveInverted:o,itemIconColorChildActiveHoverInverted:o,itemIconColorCollapsedInverted:e,itemIconColorHorizontalInverted:e,itemIconColorHoverHorizontalInverted:o,itemIconColorActiveHorizontalInverted:o,itemIconColorActiveHoverHorizontalInverted:o,itemIconColorChildActiveHorizontalInverted:o,itemIconColorChildActiveHoverHorizontalInverted:o,arrowColorInverted:e,arrowColorHoverInverted:o,arrowColorActiveInverted:o,arrowColorActiveHoverInverted:o,arrowColorChildActiveInverted:o,arrowColorChildActiveHoverInverted:o,groupTextColorInverted:n}}const st=e=>{const{borderRadius:t,textColor3:o,primaryColor:n,textColor2:i,textColor1:l,fontSize:c,dividerColor:s,hoverColor:d,primaryColorHover:f}=e;return Object.assign({borderRadius:t,color:"#0000",groupTextColor:o,itemColorHover:d,itemColorActive:ve(n,{alpha:.1}),itemColorActiveHover:ve(n,{alpha:.1}),itemColorActiveCollapsed:ve(n,{alpha:.1}),itemTextColor:i,itemTextColorHover:i,itemTextColorActive:n,itemTextColorActiveHover:n,itemTextColorChildActive:n,itemTextColorChildActiveHover:n,itemTextColorHorizontal:i,itemTextColorHoverHorizontal:f,itemTextColorActiveHorizontal:n,itemTextColorActiveHoverHorizontal:n,itemTextColorChildActiveHorizontal:n,itemTextColorChildActiveHoverHorizontal:n,itemIconColor:l,itemIconColorHover:l,itemIconColorActive:n,itemIconColorActiveHover:n,itemIconColorChildActive:n,itemIconColorChildActiveHover:n,itemIconColorCollapsed:l,itemIconColorHorizontal:l,itemIconColorHoverHorizontal:f,itemIconColorActiveHorizontal:n,itemIconColorActiveHoverHorizontal:n,itemIconColorChildActiveHorizontal:n,itemIconColorChildActiveHoverHorizontal:n,itemHeight:"42px",arrowColor:i,arrowColorHover:i,arrowColorActive:n,arrowColorActiveHover:n,arrowColorChildActive:n,arrowColorChildActiveHover:n,colorInverted:"#0000",borderColorHorizontal:"#0000",fontSize:c,dividerColor:s},ct("#BBB",n,"#FFF","#AAA"))},ut=$e({name:"Menu",common:Le,peers:{Tooltip:Eo,Dropdown:We},self:st}),vt=ut,ae=re("n-menu"),Ae=re("n-submenu"),He=re("n-menu-item-group"),ue=8;function Pe(e){const t=M(ae),{props:o,mergedCollapsedRef:n}=t,i=M(Ae,null),l=M(He,null),c=x(()=>o.mode==="horizontal"),s=x(()=>c.value?o.dropdownPlacement:"tmNodes"in e?"right-start":"right"),d=x(()=>{var m;return Math.max((m=o.collapsedIconSize)!==null&&m!==void 0?m:o.iconSize,o.iconSize)}),f=x(()=>{var m;return!c.value&&e.root&&n.value&&(m=o.collapsedIconSize)!==null&&m!==void 0?m:o.iconSize}),b=x(()=>{if(c.value)return;const{collapsedWidth:m,indent:P,rootIndent:_}=o,{root:R,isGroup:H}=e,O=_===void 0?P:_;if(R)return n.value?m/2-d.value/2:O;if(l)return P/2+l.paddingLeftRef.value;if(i)return(H?P/2:P)+i.paddingLeftRef.value}),w=x(()=>{const{collapsedWidth:m,indent:P,rootIndent:_}=o,{value:R}=d,{root:H}=e;return c.value||!H||!n.value?ue:(_===void 0?P:_)+R+ue-(m+R)/2});return{dropdownPlacement:s,activeIconSize:f,maxIconSize:d,paddingLeft:b,iconMarginRight:w,NMenu:t,NSubmenu:i}}const Ne={internalKey:{type:[String,Number],required:!0},root:Boolean,isGroup:Boolean,level:{type:Number,required:!0},title:[String,Function],extra:[String,Function]},Je=Object.assign(Object.assign({},Ne),{tmNode:{type:Object,required:!0},tmNodes:{type:Array,required:!0}}),mt=$({name:"MenuOptionGroup",props:Je,setup(e){D(Ae,null);const t=Pe(e);D(He,{paddingLeftRef:t.paddingLeft});const{mergedClsPrefixRef:o,props:n}=M(ae);return function(){const{value:i}=o,l=t.paddingLeft.value,{nodeProps:c}=n,s=c==null?void 0:c(e.tmNode.rawNode);return u("div",{class:`${i}-menu-item-group`,role:"group"},u("div",Object.assign({},s,{class:[`${i}-menu-item-group-title`,s==null?void 0:s.class],style:[(s==null?void 0:s.style)||"",l!==void 0?`padding-left: ${l}px;`:""]}),q(e.title),e.extra?u(Ie,null," ",q(e.extra)):null),u("div",null,e.tmNodes.map(d=>Re(d,n))))}}}),Qe=$({name:"MenuOptionContent",props:{collapsed:Boolean,disabled:Boolean,title:[String,Function],icon:Function,extra:[String,Function],showArrow:Boolean,childActive:Boolean,hover:Boolean,paddingLeft:Number,selected:Boolean,maxIconSize:{type:Number,required:!0},activeIconSize:{type:Number,required:!0},iconMarginRight:{type:Number,required:!0},clsPrefix:{type:String,required:!0},onClick:Function,tmNode:{type:Object,required:!0}},setup(e){const{props:t}=M(ae);return{menuProps:t,style:x(()=>{const{paddingLeft:o}=e;return{paddingLeft:o&&`${o}px`}}),iconStyle:x(()=>{const{maxIconSize:o,activeIconSize:n,iconMarginRight:i}=e;return{width:`${o}px`,height:`${o}px`,fontSize:`${n}px`,marginRight:`${i}px`}})}},render(){const{clsPrefix:e,tmNode:t,menuProps:{renderIcon:o,renderLabel:n,renderExtra:i,expandIcon:l}}=this,c=o?o(t.rawNode):q(this.icon);return u("div",{onClick:s=>{var d;(d=this.onClick)===null||d===void 0||d.call(this,s)},role:"none",class:[`${e}-menu-item-content`,{[`${e}-menu-item-content--selected`]:this.selected,[`${e}-menu-item-content--collapsed`]:this.collapsed,[`${e}-menu-item-content--child-active`]:this.childActive,[`${e}-menu-item-content--disabled`]:this.disabled,[`${e}-menu-item-content--hover`]:this.hover}],style:this.style},c&&u("div",{class:`${e}-menu-item-content__icon`,style:this.iconStyle,role:"none"},[c]),u("div",{class:`${e}-menu-item-content-header`,role:"none"},n?n(t.rawNode):q(this.title),this.extra||i?u("span",{class:`${e}-menu-item-content-header__extra`}," ",i?i(t.rawNode):q(this.extra)):null),this.showArrow?u(po,{ariaHidden:!0,class:`${e}-menu-item-content__arrow`,clsPrefix:e},{default:()=>l?l(t.rawNode):u(Xo,null)}):null)}}),Ye=Object.assign(Object.assign({},Ne),{rawNodes:{type:Array,default:()=>[]},tmNodes:{type:Array,default:()=>[]},tmNode:{type:Object,required:!0},disabled:{type:Boolean,default:!1},icon:Function,onClick:Function}),pt=$({name:"Submenu",props:Ye,setup(e){const t=Pe(e),{NMenu:o,NSubmenu:n}=t,{props:i,mergedCollapsedRef:l,mergedThemeRef:c}=o,s=x(()=>{const{disabled:m}=e;return n!=null&&n.mergedDisabledRef.value||i.disabled?!0:m}),d=L(!1);D(Ae,{paddingLeftRef:t.paddingLeft,mergedDisabledRef:s}),D(He,null);function f(){const{onClick:m}=e;m&&m()}function b(){s.value||(l.value||o.toggleExpand(e.internalKey),f())}function w(m){d.value=m}return{menuProps:i,mergedTheme:c,doSelect:o.doSelect,inverted:o.invertedRef,isHorizontal:o.isHorizontalRef,mergedClsPrefix:o.mergedClsPrefixRef,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,iconMarginRight:t.iconMarginRight,dropdownPlacement:t.dropdownPlacement,dropdownShow:d,paddingLeft:t.paddingLeft,mergedDisabled:s,mergedValue:o.mergedValueRef,childActive:oe(()=>o.activePathRef.value.includes(e.internalKey)),collapsed:x(()=>i.mode==="horizontal"?!1:l.value?!0:!o.mergedExpandedKeysRef.value.includes(e.internalKey)),dropdownEnabled:x(()=>!s.value&&(i.mode==="horizontal"||l.value)),handlePopoverShowChange:w,handleClick:b}},render(){var e;const{mergedClsPrefix:t,menuProps:{renderIcon:o,renderLabel:n}}=this,i=()=>{const{isHorizontal:c,paddingLeft:s,collapsed:d,mergedDisabled:f,maxIconSize:b,activeIconSize:w,title:m,childActive:P,icon:_,handleClick:R,menuProps:{nodeProps:H},dropdownShow:O,iconMarginRight:G,tmNode:X,mergedClsPrefix:E}=this,j=H==null?void 0:H(X.rawNode);return u("div",Object.assign({},j,{class:[`${E}-menu-item`,j==null?void 0:j.class],role:"menuitem"}),u(Qe,{tmNode:X,paddingLeft:s,collapsed:d,disabled:f,iconMarginRight:G,maxIconSize:b,activeIconSize:w,title:m,extra:this.extra,showArrow:!c,childActive:P,clsPrefix:E,icon:_,hover:O,onClick:R}))},l=()=>u(ho,null,{default:()=>{const{tmNodes:c,collapsed:s}=this;return s?null:u("div",{class:`${t}-submenu-children`,role:"menu"},c.map(d=>Re(d,this.menuProps)))}});return this.root?u(dt,Object.assign({size:"large",trigger:"hover"},(e=this.menuProps)===null||e===void 0?void 0:e.dropdownProps,{themeOverrides:this.mergedTheme.peerOverrides.Dropdown,theme:this.mergedTheme.peers.Dropdown,builtinThemeOverrides:{fontSizeLarge:"14px",optionIconSizeLarge:"18px"},value:this.mergedValue,disabled:!this.dropdownEnabled,placement:this.dropdownPlacement,keyField:this.menuProps.keyField,labelField:this.menuProps.labelField,childrenField:this.menuProps.childrenField,onUpdateShow:this.handlePopoverShowChange,options:this.rawNodes,onSelect:this.doSelect,inverted:this.inverted,renderIcon:o,renderLabel:n}),{default:()=>u("div",{class:`${t}-submenu`,role:"menuitem","aria-expanded":!this.collapsed},i(),this.isHorizontal?null:l())}):u("div",{class:`${t}-submenu`,role:"menuitem","aria-expanded":!this.collapsed},i(),l())}}),eo=Object.assign(Object.assign({},Ne),{tmNode:{type:Object,required:!0},disabled:Boolean,icon:Function,onClick:Function}),ht=$({name:"MenuOption",props:eo,setup(e){const t=Pe(e),{NSubmenu:o,NMenu:n}=t,{props:i,mergedClsPrefixRef:l,mergedCollapsedRef:c}=n,s=o?o.mergedDisabledRef:{value:!1},d=x(()=>s.value||e.disabled);function f(w){const{onClick:m}=e;m&&m(w)}function b(w){d.value||(n.doSelect(e.internalKey,e.tmNode.rawNode),f(w))}return{mergedClsPrefix:l,dropdownPlacement:t.dropdownPlacement,paddingLeft:t.paddingLeft,iconMarginRight:t.iconMarginRight,maxIconSize:t.maxIconSize,activeIconSize:t.activeIconSize,mergedTheme:n.mergedThemeRef,menuProps:i,dropdownEnabled:oe(()=>e.root&&c.value&&i.mode!=="horizontal"&&!d.value),selected:oe(()=>n.mergedValueRef.value===e.internalKey),mergedDisabled:d,handleClick:b}},render(){const{mergedClsPrefix:e,mergedTheme:t,tmNode:o,menuProps:{renderLabel:n,nodeProps:i}}=this,l=i==null?void 0:i(o.rawNode);return u("div",Object.assign({},l,{role:"menuitem",class:[`${e}-menu-item`,l==null?void 0:l.class]}),u(jo,{theme:t.peers.Tooltip,themeOverrides:t.peerOverrides.Tooltip,trigger:"hover",placement:this.dropdownPlacement,disabled:!this.dropdownEnabled||this.title===void 0,internalExtraClass:["menu-tooltip"]},{default:()=>n?n(o.rawNode):q(this.title),trigger:()=>u(Qe,{tmNode:o,clsPrefix:e,paddingLeft:this.paddingLeft,iconMarginRight:this.iconMarginRight,maxIconSize:this.maxIconSize,activeIconSize:this.activeIconSize,selected:this.selected,title:this.title,extra:this.extra,disabled:this.mergedDisabled,icon:this.icon,onClick:this.handleClick})}))}}),ft=$({name:"MenuDivider",setup(){const e=M(ae),{mergedClsPrefixRef:t,isHorizontalRef:o}=e;return()=>o.value?null:u("div",{class:`${t.value}-menu-divider`})}}),gt=ze(Je),xt=ze(eo),bt=ze(Ye);function oo(e){return e.type==="divider"||e.type==="render"}function yt(e){return e.type==="divider"}function Re(e,t){const{rawNode:o}=e,{show:n}=o;if(n===!1)return null;if(oo(o))return yt(o)?u(ft,Object.assign({key:e.key},o.props)):null;const{labelField:i}=t,{key:l,level:c,isGroup:s}=e,d=Object.assign(Object.assign({},o),{title:o.title||o[i],extra:o.titleExtra||o.extra,key:l,internalKey:l,level:c,root:c===0,isGroup:s});return e.children?e.isGroup?u(mt,me(d,gt,{tmNode:e,tmNodes:e.children,key:l})):u(pt,me(d,bt,{key:l,rawNodes:o[t.childrenField],tmNodes:e.children,tmNode:e})):u(ht,me(d,xt,{key:l,tmNode:e}))}const Fe=[z("&::before","background-color: var(--n-item-color-hover);"),p("arrow",`
 color: var(--n-arrow-color-hover);
 `),p("icon",`
 color: var(--n-item-icon-color-hover);
 `),h("menu-item-content-header",`
 color: var(--n-item-text-color-hover);
 `,[z("a",`
 color: var(--n-item-text-color-hover);
 `),p("extra",`
 color: var(--n-item-text-color-hover);
 `)])],Me=[p("icon",`
 color: var(--n-item-icon-color-hover-horizontal);
 `),h("menu-item-content-header",`
 color: var(--n-item-text-color-hover-horizontal);
 `,[z("a",`
 color: var(--n-item-text-color-hover-horizontal);
 `),p("extra",`
 color: var(--n-item-text-color-hover-horizontal);
 `)])],wt=z([h("menu",`
 background-color: var(--n-color);
 color: var(--n-item-text-color);
 overflow: hidden;
 transition: background-color .3s var(--n-bezier);
 box-sizing: border-box;
 font-size: var(--n-font-size);
 padding-bottom: 6px;
 `,[N("horizontal",`
 display: inline-flex;
 padding-bottom: 0;
 `,[h("submenu","margin: 0;"),h("menu-item","margin: 0;"),h("menu-item-content",`
 padding: 0 20px;
 border-bottom: 2px solid #0000;
 `,[z("&::before","display: none;"),N("selected","border-bottom: 2px solid var(--n-border-color-horizontal)")]),h("menu-item-content",[N("selected",[p("icon","color: var(--n-item-icon-color-active-horizontal);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-active-horizontal);
 `,[z("a","color: var(--n-item-text-color-active-horizontal);"),p("extra","color: var(--n-item-text-color-active-horizontal);")])]),N("child-active",`
 border-bottom: 2px solid var(--n-border-color-horizontal);
 `,[h("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-horizontal);
 `,[z("a",`
 color: var(--n-item-text-color-child-active-horizontal);
 `),p("extra",`
 color: var(--n-item-text-color-child-active-horizontal);
 `)]),p("icon",`
 color: var(--n-item-icon-color-child-active-horizontal);
 `)]),ne("disabled",[ne("selected, child-active",[z("&:focus-within",Me)]),N("selected",[ee(null,[p("icon","color: var(--n-item-icon-color-active-hover-horizontal);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover-horizontal);
 `,[z("a","color: var(--n-item-text-color-active-hover-horizontal);"),p("extra","color: var(--n-item-text-color-active-hover-horizontal);")])])]),N("child-active",[ee(null,[p("icon","color: var(--n-item-icon-color-child-active-hover-horizontal);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover-horizontal);
 `,[z("a","color: var(--n-item-text-color-child-active-hover-horizontal);"),p("extra","color: var(--n-item-text-color-child-active-hover-horizontal);")])])]),ee("border-bottom: 2px solid var(--n-border-color-horizontal);",Me)]),h("menu-item-content-header",[z("a","color: var(--n-item-text-color-horizontal);")])])]),N("collapsed",[h("menu-item-content",[N("selected",[z("&::before",`
 background-color: var(--n-item-color-active-collapsed) !important;
 `)]),h("menu-item-content-header","opacity: 0;"),p("arrow","opacity: 0;"),p("icon","color: var(--n-item-icon-color-collapsed);")])]),h("menu-item",`
 height: var(--n-item-height);
 margin-top: 6px;
 position: relative;
 `),h("menu-item-content",`
 box-sizing: border-box;
 line-height: 1.75;
 height: 100%;
 display: grid;
 grid-template-areas: "icon content arrow";
 grid-template-columns: auto 1fr auto;
 align-items: center;
 cursor: pointer;
 position: relative;
 padding-right: 18px;
 transition:
 background-color .3s var(--n-bezier),
 padding-left .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[z("> *","z-index: 1;"),z("&::before",`
 z-index: auto;
 content: "";
 background-color: #0000;
 position: absolute;
 left: 8px;
 right: 8px;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),N("disabled",`
 opacity: .45;
 cursor: not-allowed;
 `),N("collapsed",[p("arrow","transform: rotate(0);")]),N("selected",[z("&::before","background-color: var(--n-item-color-active);"),p("arrow","color: var(--n-arrow-color-active);"),p("icon","color: var(--n-item-icon-color-active);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-active);
 `,[z("a","color: var(--n-item-text-color-active);"),p("extra","color: var(--n-item-text-color-active);")])]),N("child-active",[h("menu-item-content-header",`
 color: var(--n-item-text-color-child-active);
 `,[z("a",`
 color: var(--n-item-text-color-child-active);
 `),p("extra",`
 color: var(--n-item-text-color-child-active);
 `)]),p("arrow",`
 color: var(--n-arrow-color-child-active);
 `),p("icon",`
 color: var(--n-item-icon-color-child-active);
 `)]),ne("disabled",[ne("selected, child-active",[z("&:focus-within",Fe)]),N("selected",[ee(null,[p("arrow","color: var(--n-arrow-color-active-hover);"),p("icon","color: var(--n-item-icon-color-active-hover);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-active-hover);
 `,[z("a","color: var(--n-item-text-color-active-hover);"),p("extra","color: var(--n-item-text-color-active-hover);")])])]),N("child-active",[ee(null,[p("arrow","color: var(--n-arrow-color-child-active-hover);"),p("icon","color: var(--n-item-icon-color-child-active-hover);"),h("menu-item-content-header",`
 color: var(--n-item-text-color-child-active-hover);
 `,[z("a","color: var(--n-item-text-color-child-active-hover);"),p("extra","color: var(--n-item-text-color-child-active-hover);")])])]),N("selected",[ee(null,[z("&::before","background-color: var(--n-item-color-active-hover);")])]),ee(null,Fe)]),p("icon",`
 grid-area: icon;
 color: var(--n-item-icon-color);
 transition:
 color .3s var(--n-bezier),
 font-size .3s var(--n-bezier),
 margin-right .3s var(--n-bezier);
 box-sizing: content-box;
 display: inline-flex;
 align-items: center;
 justify-content: center;
 `),p("arrow",`
 grid-area: arrow;
 font-size: 16px;
 color: var(--n-arrow-color);
 transform: rotate(180deg);
 opacity: 1;
 transition:
 color .3s var(--n-bezier),
 transform 0.2s var(--n-bezier),
 opacity 0.2s var(--n-bezier);
 `),h("menu-item-content-header",`
 grid-area: content;
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 opacity: 1;
 white-space: nowrap;
 overflow: hidden;
 text-overflow: ellipsis;
 color: var(--n-item-text-color);
 `,[z("a",`
 outline: none;
 text-decoration: none;
 transition: color .3s var(--n-bezier);
 color: var(--n-item-text-color);
 `,[z("&::before",`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),p("extra",`
 font-size: .93em;
 color: var(--n-group-text-color);
 transition: color .3s var(--n-bezier);
 `)])]),h("submenu",`
 cursor: pointer;
 position: relative;
 margin-top: 6px;
 `,[h("menu-item-content",`
 height: var(--n-item-height);
 `),h("submenu-children",`
 overflow: hidden;
 padding: 0;
 `,[fo({duration:".2s"})])]),h("menu-item-group",[h("menu-item-group-title",`
 margin-top: 6px;
 color: var(--n-group-text-color);
 cursor: default;
 font-size: .93em;
 height: 36px;
 display: flex;
 align-items: center;
 transition:
 padding-left .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)])]),h("menu-tooltip",[z("a",`
 color: inherit;
 text-decoration: none;
 `)]),h("menu-divider",`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 6px 18px;
 `)]);function ee(e,t){return[N("hover",e,t),z("&:hover",e,t)]}const Ct=Object.assign(Object.assign({},he.props),{options:{type:Array,default:()=>[]},collapsed:{type:Boolean,default:void 0},collapsedWidth:{type:Number,default:48},iconSize:{type:Number,default:20},collapsedIconSize:{type:Number,default:24},rootIndent:Number,indent:{type:Number,default:32},labelField:{type:String,default:"label"},keyField:{type:String,default:"key"},childrenField:{type:String,default:"children"},disabledField:{type:String,default:"disabled"},defaultExpandAll:Boolean,defaultExpandedKeys:Array,expandedKeys:Array,value:[String,Number],defaultValue:{type:[String,Number],default:null},mode:{type:String,default:"vertical"},watchProps:{type:Array,default:void 0},disabled:Boolean,show:{type:Boolean,default:!0},inverted:Boolean,"onUpdate:expandedKeys":[Function,Array],onUpdateExpandedKeys:[Function,Array],onUpdateValue:[Function,Array],"onUpdate:value":[Function,Array],expandIcon:Function,renderIcon:Function,renderLabel:Function,renderExtra:Function,dropdownProps:Object,accordion:Boolean,nodeProps:Function,items:Array,onOpenNamesChange:[Function,Array],onSelect:[Function,Array],onExpandedNamesChange:[Function,Array],expandedNames:Array,defaultExpandedNames:Array,dropdownPlacement:{type:String,default:"bottom"}}),It=$({name:"Menu",props:Ct,setup(e){const{mergedClsPrefixRef:t,inlineThemeDisabled:o}=De(e),n=he("Menu","-menu",wt,vt,e,t),i=M(ko,null),l=x(()=>{var C;const{collapsed:I}=e;if(I!==void 0)return I;if(i){const{collapseModeRef:r,collapsedRef:g}=i;if(r.value==="width")return(C=g.value)!==null&&C!==void 0?C:!1}return!1}),c=x(()=>{const{keyField:C,childrenField:I,disabledField:r}=e;return Ve(e.items||e.options,{getIgnored(g){return oo(g)},getChildren(g){return g[I]},getDisabled(g){return g[r]},getKey(g){var v;return(v=g[C])!==null&&v!==void 0?v:g.name}})}),s=x(()=>new Set(c.value.treeNodes.map(C=>C.key))),{watchProps:d}=e,f=L(null);d!=null&&d.includes("defaultValue")?_e(()=>{f.value=e.defaultValue}):f.value=e.defaultValue;const b=B(e,"value"),w=ye(b,f),m=L([]),P=()=>{m.value=e.defaultExpandAll?c.value.getNonLeafKeys():e.defaultExpandedNames||e.defaultExpandedKeys||c.value.getPath(w.value,{includeSelf:!1}).keyPath};d!=null&&d.includes("defaultExpandedKeys")?_e(P):P();const _=go(e,["expandedNames","expandedKeys"]),R=ye(_,m),H=x(()=>c.value.treeNodes),O=x(()=>c.value.getPath(w.value).keyPath);D(ae,{props:e,mergedCollapsedRef:l,mergedThemeRef:n,mergedValueRef:w,mergedExpandedKeysRef:R,activePathRef:O,mergedClsPrefixRef:t,isHorizontalRef:x(()=>e.mode==="horizontal"),invertedRef:B(e,"inverted"),doSelect:G,toggleExpand:E});function G(C,I){const{"onUpdate:value":r,onUpdateValue:g,onSelect:v}=e;g&&W(g,C,I),r&&W(r,C,I),v&&W(v,C,I),f.value=C}function X(C){const{"onUpdate:expandedKeys":I,onUpdateExpandedKeys:r,onExpandedNamesChange:g,onOpenNamesChange:v}=e;I&&W(I,C),r&&W(r,C),g&&W(g,C),v&&W(v,C),m.value=C}function E(C){const I=Array.from(R.value),r=I.findIndex(g=>g===C);if(~r)I.splice(r,1);else{if(e.accordion&&s.value.has(C)){const g=I.findIndex(v=>s.value.has(v));g>-1&&I.splice(g,1)}I.push(C)}X(I)}const j=C=>{const I=c.value.getPath(C??w.value,{includeSelf:!1}).keyPath;if(!I.length)return;const r=Array.from(R.value),g=new Set([...r,...I]);e.accordion&&s.value.forEach(v=>{g.has(v)&&!I.includes(v)&&g.delete(v)}),X(Array.from(g))},te=x(()=>{const{inverted:C}=e,{common:{cubicBezierEaseInOut:I},self:r}=n.value,{borderRadius:g,borderColorHorizontal:v,fontSize:k,itemHeight:A,dividerColor:S}=r,a={"--n-divider-color":S,"--n-bezier":I,"--n-font-size":k,"--n-border-color-horizontal":v,"--n-border-radius":g,"--n-item-height":A};return C?(a["--n-group-text-color"]=r.groupTextColorInverted,a["--n-color"]=r.colorInverted,a["--n-item-text-color"]=r.itemTextColorInverted,a["--n-item-text-color-hover"]=r.itemTextColorHoverInverted,a["--n-item-text-color-active"]=r.itemTextColorActiveInverted,a["--n-item-text-color-child-active"]=r.itemTextColorChildActiveInverted,a["--n-item-text-color-child-active-hover"]=r.itemTextColorChildActiveInverted,a["--n-item-text-color-active-hover"]=r.itemTextColorActiveHoverInverted,a["--n-item-icon-color"]=r.itemIconColorInverted,a["--n-item-icon-color-hover"]=r.itemIconColorHoverInverted,a["--n-item-icon-color-active"]=r.itemIconColorActiveInverted,a["--n-item-icon-color-active-hover"]=r.itemIconColorActiveHoverInverted,a["--n-item-icon-color-child-active"]=r.itemIconColorChildActiveInverted,a["--n-item-icon-color-child-active-hover"]=r.itemIconColorChildActiveHoverInverted,a["--n-item-icon-color-collapsed"]=r.itemIconColorCollapsedInverted,a["--n-item-text-color-horizontal"]=r.itemTextColorHorizontalInverted,a["--n-item-text-color-hover-horizontal"]=r.itemTextColorHoverHorizontalInverted,a["--n-item-text-color-active-horizontal"]=r.itemTextColorActiveHorizontalInverted,a["--n-item-text-color-child-active-horizontal"]=r.itemTextColorChildActiveHorizontalInverted,a["--n-item-text-color-child-active-hover-horizontal"]=r.itemTextColorChildActiveHoverHorizontalInverted,a["--n-item-text-color-active-hover-horizontal"]=r.itemTextColorActiveHoverHorizontalInverted,a["--n-item-icon-color-horizontal"]=r.itemIconColorHorizontalInverted,a["--n-item-icon-color-hover-horizontal"]=r.itemIconColorHoverHorizontalInverted,a["--n-item-icon-color-active-horizontal"]=r.itemIconColorActiveHorizontalInverted,a["--n-item-icon-color-active-hover-horizontal"]=r.itemIconColorActiveHoverHorizontalInverted,a["--n-item-icon-color-child-active-horizontal"]=r.itemIconColorChildActiveHorizontalInverted,a["--n-item-icon-color-child-active-hover-horizontal"]=r.itemIconColorChildActiveHoverHorizontalInverted,a["--n-arrow-color"]=r.arrowColorInverted,a["--n-arrow-color-hover"]=r.arrowColorHoverInverted,a["--n-arrow-color-active"]=r.arrowColorActiveInverted,a["--n-arrow-color-active-hover"]=r.arrowColorActiveHoverInverted,a["--n-arrow-color-child-active"]=r.arrowColorChildActiveInverted,a["--n-arrow-color-child-active-hover"]=r.arrowColorChildActiveHoverInverted,a["--n-item-color-hover"]=r.itemColorHoverInverted,a["--n-item-color-active"]=r.itemColorActiveInverted,a["--n-item-color-active-hover"]=r.itemColorActiveHoverInverted,a["--n-item-color-active-collapsed"]=r.itemColorActiveCollapsedInverted):(a["--n-group-text-color"]=r.groupTextColor,a["--n-color"]=r.color,a["--n-item-text-color"]=r.itemTextColor,a["--n-item-text-color-hover"]=r.itemTextColorHover,a["--n-item-text-color-active"]=r.itemTextColorActive,a["--n-item-text-color-child-active"]=r.itemTextColorChildActive,a["--n-item-text-color-child-active-hover"]=r.itemTextColorChildActiveHover,a["--n-item-text-color-active-hover"]=r.itemTextColorActiveHover,a["--n-item-icon-color"]=r.itemIconColor,a["--n-item-icon-color-hover"]=r.itemIconColorHover,a["--n-item-icon-color-active"]=r.itemIconColorActive,a["--n-item-icon-color-active-hover"]=r.itemIconColorActiveHover,a["--n-item-icon-color-child-active"]=r.itemIconColorChildActive,a["--n-item-icon-color-child-active-hover"]=r.itemIconColorChildActiveHover,a["--n-item-icon-color-collapsed"]=r.itemIconColorCollapsed,a["--n-item-text-color-horizontal"]=r.itemTextColorHorizontal,a["--n-item-text-color-hover-horizontal"]=r.itemTextColorHoverHorizontal,a["--n-item-text-color-active-horizontal"]=r.itemTextColorActiveHorizontal,a["--n-item-text-color-child-active-horizontal"]=r.itemTextColorChildActiveHorizontal,a["--n-item-text-color-child-active-hover-horizontal"]=r.itemTextColorChildActiveHoverHorizontal,a["--n-item-text-color-active-hover-horizontal"]=r.itemTextColorActiveHoverHorizontal,a["--n-item-icon-color-horizontal"]=r.itemIconColorHorizontal,a["--n-item-icon-color-hover-horizontal"]=r.itemIconColorHoverHorizontal,a["--n-item-icon-color-active-horizontal"]=r.itemIconColorActiveHorizontal,a["--n-item-icon-color-active-hover-horizontal"]=r.itemIconColorActiveHoverHorizontal,a["--n-item-icon-color-child-active-horizontal"]=r.itemIconColorChildActiveHorizontal,a["--n-item-icon-color-child-active-hover-horizontal"]=r.itemIconColorChildActiveHoverHorizontal,a["--n-arrow-color"]=r.arrowColor,a["--n-arrow-color-hover"]=r.arrowColorHover,a["--n-arrow-color-active"]=r.arrowColorActive,a["--n-arrow-color-active-hover"]=r.arrowColorActiveHover,a["--n-arrow-color-child-active"]=r.arrowColorChildActive,a["--n-arrow-color-child-active-hover"]=r.arrowColorChildActiveHover,a["--n-item-color-hover"]=r.itemColorHover,a["--n-item-color-active"]=r.itemColorActive,a["--n-item-color-active-hover"]=r.itemColorActiveHover,a["--n-item-color-active-collapsed"]=r.itemColorActiveCollapsed),a}),V=o?Ee("menu",x(()=>e.inverted?"a":"b"),te,e):void 0;return{mergedClsPrefix:t,controlledExpandedKeys:_,uncontrolledExpanededKeys:m,mergedExpandedKeys:R,uncontrolledValue:f,mergedValue:w,activePath:O,tmNodes:H,mergedTheme:n,mergedCollapsed:l,cssVars:o?void 0:te,themeClass:V==null?void 0:V.themeClass,onRender:V==null?void 0:V.onRender,showOption:j}},render(){const{mergedClsPrefix:e,mode:t,themeClass:o,onRender:n}=this;return n==null||n(),u("div",{role:t==="horizontal"?"menubar":"menu",class:[`${e}-menu`,o,`${e}-menu--${t}`,this.mergedCollapsed&&`${e}-menu--collapsed`],style:this.cssVars},this.tmNodes.map(i=>Re(i,this.$props)))}});const de=e=>(Io("data-v-24c8a6d0"),e=e(),zo(),e),zt={class:"imgs"},St=de(()=>F("img",{class:"carousel-img",src:So},null,-1)),At=de(()=>F("img",{class:"carousel-img",src:Ao},null,-1)),Ht=de(()=>F("img",{class:"carousel-img",src:Ho},null,-1)),Pt=de(()=>F("img",{class:"carousel-img",src:Po},null,-1)),Nt={class:"custom-dots"},Rt=["onClick"],_t=de(()=>F("div",{class:"text"},[F("div",{class:"header"}," Material Intelligent Design and Innovation Service Cloud Platform "),F("div",{class:"twotitle"},[we(" An Intelligent material design platform based on information technology,"),F("br"),we(" integrating material simulation, data collection, data management and applications ")])],-1)),kt={class:"content"},Tt={class:"left"},Kt={key:0},Ot={key:1},Ft={class:"right"},Mt={class:"title"},$t={class:"cont"},Lt={class:"btn"},Bt={__name:"AboutView",setup(e){const t=L([]),o=L(0),n=L("0"),i=(s,d)=>{o.value=s},l=s=>{s!==""&&s!==void 0&&s!=="/collection"?window.location.href=s:s=="/collection"&&(sessionStorage.setItem("activeTab","/collection"),c.push({path:"/collection"}))},c=bo();return pe(()=>c.currentRoute.value.path,s=>{o.value=0,n.value="0",c.currentRoute.value.query.id==1?t.value=[{label:"CrysPAI",img:"./imgs/header.png",text:"A crystal structure prediction package based on artificial intelligence (CrySPAI)",url:"http://mat.aicnic.cn/cryspai/index",key:"0"},{label:"TDAP",img:"./imgs/header1.png",text:"Time Dependent Ab-initio Package",key:"1"}]:c.currentRoute.value.query.id==2&&(t.value=[{label:"Materials Data Collection",img:"./imgs/header.png",text:"A data collection software for material science, building database for any calculation software.",url:"/collection",key:"0"},{label:"DataBase",img:"./imgs/header1.png",text:"Material database facilitates materials scientific data sharing and application.",url:"http://mat.aicnic.cn/search",key:"1"}])},{immediate:!0,deep:!0}),(s,d)=>{const f=wo,b=It,w=Uo;return ie(),le("div",null,[F("div",zt,[xe(f,{autoplay:""},{dots:be(({total:m,currentIndex:P,to:_})=>[F("ul",Nt,[(ie(!0),le(Ie,null,Co(m,R=>(ie(),le("li",{key:R,class:No({["is-active"]:P===R-1}),onClick:H=>_(R-1)},null,10,Rt))),128))])]),default:be(()=>[St,At,Ht,Pt]),_:1}),_t]),F("div",kt,[F("div",Tt,[U(c).currentRoute.value.query.id==1?(ie(),le("h1",Kt,"Material Simulation")):ke("",!0),U(c).currentRoute.value.query.id==2?(ie(),le("h1",Ot,"Material Data")):ke("",!0),xe(b,{options:U(t),"default-value":"0",value:U(n),"onUpdate:value":[d[0]||(d[0]=m=>yo(n)?n.value=m:null),i]},null,8,["options","value"])]),F("div",Ft,[F("h4",Mt,Te(U(t)[U(o)].label),1),F("p",$t,Te(U(t)[U(o)].text),1),F("div",Lt,[xe(w,{type:"error",onClick:d[1]||(d[1]=m=>l(U(t)[U(o)].url))},{default:be(()=>[we("Detail")]),_:1})])])])])}}},Ut=xo(Bt,[["__scopeId","data-v-24c8a6d0"]]);export{Ut as default};
